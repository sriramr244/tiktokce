from setuptools import setup, find_packages

setup(
    name="social_content_engine",  # Package name
    version="0.1.0",  # Initial version
    description="A modular backend system for automating content creation for social media platforms",
    long_description=open("README.md").read(),  # Long description from README
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/yourusername/social_content_engine",  # Replace with your project's URL
    packages=find_packages(where="src"),  # Automatically find packages in src/
    package_dir={"": "src"},  # Root directory for packages is src/
    include_package_data=True,
    install_requires=[
        "openai",
        "gtts",
        "moviepy",
        "flask",
        "PyPDF2",
        # Add other dependencies here
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",  # Specify Python version requirement
)
