from typing import Optional, Union
import os
from social_content_engine.config.settings import Config
from social_content_engine.document_processing.pdf_processor import PDFProcessor
from social_content_engine.content_generation.ai_content_generator import (
    AIContentGenerator,
)
from social_content_engine.audio_conversion.text_to_speech import TextToSpeechConverter
from social_content_engine.video_creation.video_overlay import VideoCreator
from social_content_engine.cta_integration.add_cta import CTAAdder
from social_content_engine.utils.logger import setup_logger
from social_content_engine.utils.decorators import (
    log_execution,
    handle_errors,
    validate_input,
)

# Set up the logger
logger = setup_logger(__name__)


class SocialContentEngine:
    """
    The main interface for the Social Content Engine, orchestrating document processing,
    content generation, audio conversion, video creation, and CTA integration.
    """

    def __init__(
        self,
        api_key: str,
        config: Optional[Config] = None,
        background_video_file: Optional[str] = None,
        output_video_file: Optional[str] = None,
        audio_file: Optional[str] = None,
        cta_text: Optional[str] = None,
    ):
        """
        Initializes the SocialContentEngine with mandatory API key and optional configuration settings.

        Args:
            api_key (str): OpenAI API key for content generation.
            config (Config, optional): Custom configuration for the engine.
            background_video_file (str, optional): Path to the background video file.
            output_video_file (str, optional): Path to the output video file.
            audio_file (str, optional): Path to the audio file.
            cta_text (str, optional): Custom call-to-action text.
        """
        self.config = config or Config()
        base_path = os.path.join(os.path.dirname(__file__), "data")
        self.api_key = api_key
        self.background_video_file = background_video_file or os.path.join(
            base_path, "Default_Video.mp4"
        )
        self.output_video_file = output_video_file or os.path.join(
            base_path, "final_video_with_cta.mp4"
        )
        self.audio_file = audio_file or os.path.join(base_path, "output.mp3")
        self.cta_text = cta_text or self.config.get_default_cta_text()

        # Initializing components
        self.pdf_processor = PDFProcessor()
        self.content_generator = AIContentGenerator(api_key=self.api_key)
        self.tts_converter = TextToSpeechConverter()
        self.video_creator = VideoCreator()
        self.cta_adder = CTAAdder()

    @log_execution
    @handle_errors
    @validate_input
    def process_pdf(self, pdf_file: str) -> str:
        """
        Extracts text from a PDF file.

        Args:
            pdf_file (str): Path to the PDF file.

        Returns:
            str: Extracted text from the PDF.
        """
        with open(pdf_file, "rb") as file:
            return self.pdf_processor.extract_text(file)

    @log_execution
    @handle_errors
    @validate_input
    def generate_content(self, text: str) -> str:
        """
        Generates AI-based content from input text using OpenAI's API.

        Args:
            text (str): The input text to generate content from.

        Returns:
            str: Generated content.
        """
        return self.content_generator.generate_content(text)

    @log_execution
    @handle_errors
    def convert_text_to_speech(self, text: str) -> str:
        """
        Converts input text to speech and saves it as an audio file.

        Args:
            text (str): The input text to convert to speech.

        Returns:
            str: Path to the saved audio file.
        """
        return self.tts_converter.convert(text, output_file=self.audio_file)

    @log_execution
    @handle_errors
    def create_video(
        self,
        content: str,
        audio_file: str,
        background_video_file: Optional[str] = None,
        output_video_file: Optional[str] = None,
    ) -> str:
        """
        Creates a video by overlaying content and audio onto a background video.

        Args:
            content (str): The content to overlay as text.
            audio_file (str): Path to the audio file.
            background_video_file (str, optional): Path to the background video file.
            output_video_file (str, optional): Path to the output video file.

        Returns:
            str: Path to the saved video file.
        """
        return self.video_creator.create(
            content=content,
            audio_file=audio_file,
            video_file=background_video_file or self.background_video_file,
            output_file=output_video_file or self.output_video_file,
        )

    @log_execution
    @handle_errors
    def add_cta(self, video_file: str, cta_text: Optional[str] = None) -> str:
        """
        Adds a call-to-action (CTA) at the end of a video.

        Args:
            video_file (str): Path to the video file.
            cta_text (str, optional): Custom CTA text.

        Returns:
            str: Path to the final video file with the CTA added.
        """
        return self.cta_adder.add(
            video_file=video_file,
            cta_text=cta_text or self.cta_text,
            output_file=self.output_video_file,
        )

    @log_execution
    @handle_errors
    def process_and_create_video(
        self,
        input_data: Union[str, bytes],
        is_pdf: bool = True,
        background_video_file: Optional[str] = None,
        cta_text: Optional[str] = None,
        output_video_file: Optional[str] = None,
    ) -> str:
        """
        Processes either a PDF file or plain text, generates a video, and optionally adds a CTA.

        Args:
            input_data (str or bytes): The input data (PDF or plain text).
            is_pdf (bool): Whether the input data is a PDF file.
            background_video_file (str, optional): Path to the background video file.
            cta_text (str, optional): Call-to-action text to add to the video.
            output_video_file (str, optional): Path to the output video file.

        Returns:
            str: Path to the final video file.
        """
        text = self.process_pdf(input_data) if is_pdf else input_data
        generated_content = self.generate_content(text)
        audio_file = self.convert_text_to_speech(generated_content)
        video_file = self.create_video(
            generated_content, audio_file, background_video_file, output_video_file
        )
        if cta_text or self.cta_text:
            video_file = self.add_cta(video_file, cta_text)
        return video_file
