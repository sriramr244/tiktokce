from moviepy.editor import VideoFileClip, TextClip, CompositeVideoClip, AudioFileClip
from social_content_engine.utils.logger import setup_logger

# Set up a logger for the VideoCreator
logger = setup_logger(__name__)


class VideoCreator:
    """
    A class to create videos by overlaying content and audio on a background video.
    """

    @staticmethod
    def create(
        content: str,
        audio_file: str,
        video_file: str = "background.mp4",
        output_file: str = "final_video.mp4",
    ) -> str:
        """
        Create a video by overlaying content and audio on a background video.

        Args:
            content (str): The content to overlay as text.
            audio_file (str): Path to the audio file.
            video_file (str): Path to the background video file. Defaults to 'background.mp4'.
            output_file (str): The name of the output video file. Defaults to 'final_video.mp4'.

        Returns:
            str: The path to the saved video file.
        """
        try:
            logger.info(
                f"Starting video creation. Content: {content}, Audio File: {audio_file}, Video File: {video_file}"
            )

            # Load the background video and audio file
            video = VideoFileClip(video_file)
            audio = AudioFileClip(audio_file)
            audio_duration = audio.duration
            video_duration = video.duration

            logger.info(
                f"Audio duration: {audio_duration} seconds, Video duration: {video_duration} seconds"
            )

            # Adjust the video duration to match the audio if necessary
            if video_duration > audio_duration:
                logger.info("Trimming video to match audio length")
                video = video.subclip(0, audio_duration)
            elif video_duration < audio_duration:
                logger.info("Extending video to match audio length")
                last_frame = video.get_frame(video.duration - 1)
                last_frame_clip = (
                    ImageClip(last_frame)
                    .set_duration(audio_duration - video_duration)
                    .set_fps(video.fps)
                )
                video = concatenate_videoclips([video, last_frame_clip])

            # Create a text clip for the content
            text_clip = TextClip(content, fontsize=24, color="white", size=video.size)
            text_clip = text_clip.set_pos("center").set_duration(audio_duration)

            # Set the audio to the video and overlay the text
            video = video.set_audio(audio)
            final_clip = CompositeVideoClip([video, text_clip])
            final_clip = final_clip.set_duration(audio_duration)

            # Write the final video file
            final_clip.write_videofile(output_file, codec="libx264", audio_codec="aac")
            logger.info(f"Successfully created video and saved to {output_file}.")
            return output_file
        except Exception as e:
            logger.error(f"Error creating video: {e}")
            raise RuntimeError(f"Error creating video: {e}")


# Example usage:
# content = "This is a sample video content."
# audio_file = "output.mp3"
# video_creator = VideoCreator()
# final_video = video_creator.create(content, audio_file)
# print(f"Video saved to {final_video}")
