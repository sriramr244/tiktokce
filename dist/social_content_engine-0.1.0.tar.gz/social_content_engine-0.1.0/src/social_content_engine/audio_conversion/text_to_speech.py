from gtts import gTTS
from social_content_engine.utils.logger import setup_logger

# Set up a logger for the TextToSpeechConverter
logger = setup_logger(__name__)


class TextToSpeechConverter:
    """
    A class to convert text to speech.
    """

    @staticmethod
    def convert(text: str, output_file: str = "output.mp3") -> str:
        """
        Convert text to speech and save it as an audio file.

        Args:
            text (str): The text to convert.
            output_file (str): The name of the output audio file. Defaults to 'output.mp3'.

        Returns:
            str: The path to the saved audio file.
        """
        try:
            logger.info(f"Starting text-to-speech conversion.")
            tts = gTTS(text)
            tts.save(output_file)
            logger.info(f"Successfully saved audio to {output_file}.")
            return output_file
        except Exception as e:
            logger.error(f"Error converting text to speech: {e}")
            raise RuntimeError(f"Error converting text to speech: {e}")


# Example usage:
# text = "Hello, this is a test of the text-to-speech conversion."
# converter = TextToSpeechConverter()
# audio_file = converter.convert(text)
# print(f"Audio saved to {audio_file}")
