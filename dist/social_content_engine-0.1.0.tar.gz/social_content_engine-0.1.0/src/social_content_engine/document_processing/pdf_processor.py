import PyPDF2
from social_content_engine.utils.logger import setup_logger

# Set up a logger for the PDFProcessor
logger = setup_logger(__name__)


class PDFProcessor:
    """
    A class to process PDF files and extract text.
    """

    @staticmethod
    def extract_text(pdf_file) -> str:
        """
        Extract text from a PDF file.

        Args:
            pdf_file (file-like object): A file-like object representing the PDF.

        Returns:
            str: The extracted text from the PDF.
        """
        try:
            logger.info(f"Starting text extraction from PDF: {pdf_file.name}")
            reader = PyPDF2.PdfFileReader(pdf_file)
            text = ""

            # Iterate over all pages in the PDF
            for page_num in range(reader.numPages):
                page = reader.getPage(page_num)
                text += page.extract_text()

            logger.info(f"Successfully extracted text from PDF: {pdf_file.name}")
            return text
        except Exception as e:
            logger.error(f"Error extracting text from PDF: {e}")
            raise RuntimeError(f"Error extracting text from PDF: {e}")


# Example usage:
# with open('example.pdf', 'rb') as pdf_file:
#     processor = PDFProcessor()
#     extracted_text = processor.extract_text(pdf_file)
#     print(extracted_text)
